"use client";

import { useEffect, useState } from "react";

import Header from "@/components/layout/Header";
import Card from "@/components/layout/Card";
import ParticipanteSelect from "@/components/forms/ParticipanteSelect";
import Placar from "@/components/forms/Placar";
import Button from "@/components/ui/Button";

import { buscarJogoAberto } from "@/services/jogos";
import { criarParticipante } from "@/services/participantes";
import { salvarPalpite } from "@/services/palpites";

export default function Home() {
  const [jogoId, setJogoId] = useState("");
  const [participanteId, setParticipanteId] = useState("");
  const [novoNome, setNovoNome] = useState("");
  const [golsBrasil, setGolsBrasil] = useState(0);
  const [golsAdversario, setGolsAdversario] = useState(0);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    async function carregar() {
      try {
        const jogo = await buscarJogoAberto();

        if (jogo) {
          setJogoId(jogo.id);
        } else {
          alert("Nenhum jogo com palpites abertos.");
        }
      } catch (e: any) {
        console.error(e);

        if (e?.message) {
          alert(e.message);
        } else {
          alert(JSON.stringify(e, null, 2));
        }
      }
    }

    carregar();
  }, []);

  async function confirmar() {
    try {
      setSalvando(true);

      if (!jogoId) {
        throw new Error("Nenhum jogo aberto encontrado.");
      }

      let participante = participanteId;

      if (!participante) {
        throw new Error("Selecione um participante.");
      }

      if (participante === "novo") {
        if (!novoNome.trim()) {
          throw new Error("Informe o nome.");
        }

        const novo = await criarParticipante(novoNome.trim());

        participante = novo.id;
      }

      await salvarPalpite(
        jogoId,
        participante,
        golsBrasil,
        golsAdversario
      );

      alert("Palpite salvo com sucesso.");

    } catch (e: any) {
      console.error(e);

      if (e?.message) {
        alert(e.message);
      } else {
        alert(JSON.stringify(e, null, 2));
      }
    } finally {
      setSalvando(false);
    }
  }

  return (
    <main className="min-h-screen bg-green-100 flex items-center justify-center p-6">

      <Card>

        <Header />

        <ParticipanteSelect
          value={participanteId}
          onChange={setParticipanteId}
        />

        {participanteId === "novo" && (
          <input
            className="border rounded-xl p-4 w-full mt-4"
            placeholder="Nome"
            value={novoNome}
            onChange={(e) => setNovoNome(e.target.value)}
          />
        )}

        <Placar
          golsBrasil={golsBrasil}
          golsAdversario={golsAdversario}
          setGolsBrasil={setGolsBrasil}
          setGolsAdversario={setGolsAdversario}
        />

        <div className="mt-6">

          <Button
            onClick={confirmar}
            disabled={salvando}
          >
            {salvando ? "Salvando..." : "Confirmar Palpite"}
          </Button>

        </div>

      </Card>

    </main>
  );
}