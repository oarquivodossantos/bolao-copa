"use client";

import { useEffect, useState } from "react";

import {
  listarJogos,
  abrirJogo,
  fecharJogo,
  excluirJogo
} from "@/services/adminJogos";

interface Jogo {
  id: string;
  adversario: string;
  fase: string;
  data_hora: string;
  premio: string;
  palpites_abertos: boolean;
}

export default function ListaJogos() {

  const [jogos, setJogos] = useState<Jogo[]>([]);
  const [carregando, setCarregando] = useState(false);

  useEffect(() => {
    carregar();
  }, []);

  async function carregar() {
    const lista = await listarJogos();
    setJogos(lista);
  }

  async function abrir(id: string) {

    try {

      setCarregando(true);

      await abrirJogo(id);

      await carregar();

    } catch (e: any) {

      alert(e.message);

    } finally {

      setCarregando(false);

    }

  }

  async function fechar(id: string) {

    try {

      setCarregando(true);

      await fecharJogo(id);

      await carregar();

    } catch (e: any) {

      alert(e.message);

    } finally {

      setCarregando(false);

    }

  }

  async function excluir(id: string) {

    if (!confirm("Excluir este jogo?")) return;

    try {

      setCarregando(true);

      await excluirJogo(id);

      await carregar();

    } catch (e: any) {

      alert(e.message);

    } finally {

      setCarregando(false);

    }

  }

  return (

    <div className="bg-white rounded-xl shadow mt-8 overflow-hidden">

      <table className="w-full">

        <thead className="bg-gray-100">

          <tr>

            <th className="p-4 text-left">Adversário</th>
            <th className="p-4 text-left">Fase</th>
            <th className="p-4 text-left">Data</th>
            <th className="p-4 text-left">Prêmio</th>
            <th className="p-4 text-center">Status</th>
            <th className="p-4 text-center">Ações</th>

          </tr>

        </thead>

        <tbody>

          {jogos.map((jogo) => (

            <tr
              key={jogo.id}
              className="border-t"
            >

              <td className="p-4">

                {jogo.adversario}

              </td>

              <td className="p-4">

                {jogo.fase}

              </td>

              <td className="p-4">

                {new Date(jogo.data_hora).toLocaleString("pt-BR")}

              </td>

              <td className="p-4">

                {jogo.premio}

              </td>

              <td className="text-center">

                {jogo.palpites_abertos
                  ? "🟢 Aberto"
                  : "🔴 Fechado"}

              </td>

              <td className="text-center space-x-2">

                {jogo.palpites_abertos ? (

                  <button
                    disabled={carregando}
                    onClick={() => fechar(jogo.id)}
                    className="bg-red-600 text-white px-3 py-2 rounded-lg"
                  >
                    Fechar
                  </button>

                ) : (

                  <button
                    disabled={carregando}
                    onClick={() => abrir(jogo.id)}
                    className="bg-green-600 text-white px-3 py-2 rounded-lg"
                  >
                    Abrir
                  </button>

                )}

                <button
                  disabled={carregando}
                  className="bg-blue-600 text-white px-3 py-2 rounded-lg"
                >
                  Editar
                </button>

                <button
                  disabled={carregando}
                  onClick={() => excluir(jogo.id)}
                  className="bg-gray-700 text-white px-3 py-2 rounded-lg"
                >
                  Excluir
                </button>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>

  );

}