import { supabase } from "@/lib/supabase";

export async function criarJogo(
  adversario: string,
  fase: string,
  dataHora: string,
  premio: string
) {
  const { data, error } = await supabase
    .from("jogos")
    .insert({
      adversario,
      fase,
      data_hora: dataHora,
      premio,
      palpites_abertos: false,
      placar_brasil: null,
      placar_adversario: null,
    })
    .select()
    .single();

  if (error) throw error;

  return data;
}

export async function listarJogos() {
  const { data, error } = await supabase
    .from("jogos")
    .select("*")
    .order("data_hora", { ascending: false });

  if (error) throw error;

  return data ?? [];
}

export async function atualizarJogo(
  id: string,
  adversario: string,
  fase: string,
  dataHora: string,
  premio: string
) {
  const { error } = await supabase
    .from("jogos")
    .update({
      adversario,
      fase,
      data_hora: dataHora,
      premio,
    })
    .eq("id", id);

  if (error) throw error;
}

export async function excluirJogo(id: string) {
  const { error } = await supabase
    .from("jogos")
    .delete()
    .eq("id", id);

  if (error) throw error;
}

export async function abrirJogo(id: string) {

  const { error: fechar } = await supabase
    .from("jogos")
    .update({
      palpites_abertos: false,
    })
    .neq("id", "");

  if (fechar) throw fechar;

  const { error } = await supabase
    .from("jogos")
    .update({
      palpites_abertos: true,
    })
    .eq("id", id);

  if (error) throw error;
}

export async function fecharJogo(id: string) {
  const { error } = await supabase
    .from("jogos")
    .update({
      palpites_abertos: false,
    })
    .eq("id", id);

  if (error) throw error;
}